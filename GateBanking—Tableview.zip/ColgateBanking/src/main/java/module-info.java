module org.ColgateBankingTransaction {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.ColgateBankingTransaction to javafx.fxml;
    exports org.ColgateBankingTransaction;
}